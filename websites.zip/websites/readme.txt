Gia google vazoume
<meta name="robots" content="noindex">

Gia na apenergopoihsoume ta klik
Sto Index.html mesa sto body vazoume
<body style="pointer-events: none;">

kai episis ta script
<script  src='print.js'></script>
<script  src='disableMouseRightClick.js'></script>

(apenergopoioun print screen kai right click)