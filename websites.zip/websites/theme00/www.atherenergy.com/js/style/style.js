// common script goes here

$(document).ready(function () {

    

});